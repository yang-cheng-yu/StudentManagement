package org.example.studentmanagement;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class Controller implements Initializable {

    FileChooser fileChooser = new FileChooser();

    @FXML
    private TextField idSearch;

    @FXML
    private Label path;

    @FXML
    private Label sms;

    @FXML
    void addStudentGUI(MouseEvent event) {

    }

    @FXML
    void chooseFile(MouseEvent event) {
        File file = fileChooser.showOpenDialog(new Stage());
        try {
            Scanner scanner = new Scanner(file);
            path.setText(file.getPath());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

    @FXML
    void exit(MouseEvent event) {
        Platform.exit();
    }

    @FXML
    void load(MouseEvent event) {

    }

    @FXML
    void min(MouseEvent event) {
        Stage stage = (Stage) sms.getScene().getWindow();
        stage.setIconified(true);
    }

    @FXML
    void save(MouseEvent event) {

    }

    @FXML
    void search(MouseEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        fileChooser.setInitialDirectory(new File("C:\\"));
    }
}
